#include "timeLapse.h"

#if defined(_SD_H_) || defined(__SD_H__)

bool initSD() {
  // Initialize SD card
  if (!SD.begin(21)) {  // beware, GPIO21 is LED_BUILTIN
    Serial.println("Card Mount Failed");
    return false;
  }

  // Determine if the type of SD card is available
  uint8_t cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("No SD card attached");
    return false;
  }

  Serial.print("SD Card Type: ");
  if (cardType == CARD_MMC) {
    Serial.println("MMC");
  } else if (cardType == CARD_SD) {
    Serial.println("SDSC");
  } else if (cardType == CARD_SDHC) {
    Serial.println("SDHC");
  } else {
    Serial.println("UNKNOWN");
  }

  uint64_t cardSize = SD.cardSize() / (1024 * 1024);
  Serial.printf("SD Card Size: %lluMB", cardSize);
  Serial.printf(" (Used space: %lluMB)\n", SD.usedBytes() / (1024 * 1024));
  return true;
}

// SD card write file
void writeFile(const char *path, uint8_t *data, size_t len) {
  File file = SD.open(path, FILE_WRITE);
  if (!file) {
    Serial.printf("Failed to open file %s for writing\n", path);
  } else {
    if (file.write(data, len) == len) {
      Serial.printf("File: %s written successfully\n", path);
    } else {
      Serial.printf("File: %s write failed\n", path);
    }
    file.close();
  }
}

void deleteFile(const char *path) {
  if (SD.remove(path)) {
    Serial.printf("File %s deleted\n", path);
  } else {
    Serial.printf("File %s delete failed\n", path);
  }
}

void listDir(const char *dirname) {
  Serial.printf("Listing directory: %s\n", dirname);

  File root = SD.open(dirname);
  if (!root || !root.isDirectory()) {
    Serial.println("Failed to open directory");
  } else {
    File file = root.openNextFile();
    while (file) {
      if (!file.isDirectory()) {
        Serial.print("  FILE: ");
        Serial.print(file.name());
        Serial.print("  SIZE: ");
        Serial.print(file.size());
        Serial.print("  DATE: ");
        time_t t = file.getLastWrite();  
        struct tm * fileTime = localtime(&t);
        Serial.println(fileTime, "%B %d %Y %H:%M:%S");
      }
      file = root.openNextFile();
    }
    file.close();
    root.close();
  }
}

void listDirJSON(const char *dirname, char *buffer, size_t bufferSize) {
  strcpy(buffer, "[ ");  // start a JSON array

  File root = SD.open("/");
  if (root && root.isDirectory()) {
    File file = root.openNextFile();
    while (file && strlen(buffer) < (bufferSize - 100)) {
      if (!file.isDirectory()) {
//      sprintf(&buffer[strlen(buffer)], "{\"name\":\"%s\",\"size\":%d},", file.name(), file.size());  // append to buffer
        
        time_t t = file.getLastWrite();  
        struct tm * fileTime = localtime(&t);
        sprintf(&buffer[strlen(buffer)], "{\"name\":\"%s\",\"size\":%d,\"date\":\"%02d/%02d/%d %02d:%02d:%02d\"},",
          file.name(), file.size(),
          fileTime->tm_mon + 1, fileTime->tm_mday, fileTime->tm_year + 1900,
          fileTime->tm_hour, fileTime->tm_min, fileTime->tm_sec);  // append to buffer
      }
      file = root.openNextFile();
    }
  }
  strcpy(&buffer[strlen(buffer) - 1], "]");  // end JSON array
}

void eraseSD(const char *filter) {
  int fileCount = 0;
  File root = SD.open("/");
  if (!root && !root.isDirectory()) {
    Serial.println("Failed to open directory");
  } else {
    File file = root.openNextFile();
    char path[32];
    while (file) {
      if (!file.isDirectory()) {
        if(strstr(file.name(), filter)) {     // only delete files that match filter
          sprintf(path, "/%s", file.name());  // prepend a slash
          if (SD.remove(path)) {
            DEBUG_SERIAL.printf("File %s deleted\n", path);
            fileCount++;
          } else {
            DEBUG_SERIAL.printf("File %s delete failed\n", path);
          }
        }
      }
      file = root.openNextFile();
    }
    file.close();
    root.close();
    Serial.printf("%d files deleted\n", fileCount);

    imageCount = 1;  // reset image counter too
    preferences.putInt("imageCount", imageCount);
  }
}

void testSD() {
  char filename[32];
  char readBuf[32];
  unsigned long prevTimeStamp = millis();

  for(int i=0; i<100; i++) {
    sprintf(filename, "/test%02d.txt", i);
    File file = SD.open(filename, FILE_WRITE);
    if (!file) {
      Serial.printf("Failed to open file %s for writing\n", filename);
    } else {
      if (file.write((uint8_t*)"hello world", 12) == 12) {
        DEBUG_SERIAL.printf("File: %s written successfully\n", filename);
      } else {
        Serial.printf("File: %s write failed\n", filename);
      }
      file.close();
    }
  }
  Serial.print("SD write time:"); Serial.println(millis() - prevTimeStamp);

  prevTimeStamp = millis();
  for(int i=0; i<100; i++) {
    sprintf(filename, "/test%02d.txt", i);
    File file = SD.open(filename, FILE_READ);
    if(file && file.available()) {
      int16_t numChars = file.read((uint8_t*)readBuf, sizeof(readBuf));
      DEBUG_SERIAL.printf("%s\n", readBuf);
    }
    file.close();
  }
  Serial.print("SD read time:"); Serial.println(millis() - prevTimeStamp);

  prevTimeStamp = millis();
  eraseSD(".txt");
  Serial.print("SD erase time:"); Serial.println(millis() - prevTimeStamp);
}

#endif