#include "esp_camera.h"
#include "Preferences.h"
#include "SD.h"
#include "WiFi.h"
#include "ESPAsyncWebSrv.h"
#include <esp_sntp.h> /* for sntp_set_time_sync_notification_cb() function */

#define DEBUG false  //set to true for debug output
#define DEBUG_SERIAL if(DEBUG)Serial

#define CAMERA_MODEL_XIAO_ESP32S3  // Has PSRAM

#include "camera_pins.h"

extern int imageCount;
extern unsigned long sleepTimer;
extern Preferences preferences;
extern struct tm localTime;

extern void resetSleepTimer();

extern bool initWiFi();
extern void configServer();

extern bool initSD();
extern void writeFile(const char *, uint8_t *, size_t);
extern void eraseSD(const char *);
extern void deleteFile(const char *);
extern void listDir(const char *);
extern void listDirJSON(const char *, char *, size_t);
extern void testSD();

extern void setTime();