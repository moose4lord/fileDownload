#include "timeLapse.h"
#include <sys/time.h>

#pragma message("Compile time stamp " __DATE__ " " __TIME__)

struct tm localTime = { 0 };

void timeSyncCallback(struct timeval *tv) {
  Serial.print("\nSNTP sync completed. Time is "); Serial.print(ctime(&tv->tv_sec)); Serial.flush();
  localtime_r(&tv->tv_sec, &localTime);  // update the localTime global variable immediately
}

bool isLocalTimeValid() {
  return (localTime.tm_year >= (2023 - 1900));
}

// converts from __DATE__ and __TIME__ compile time macros to time_t struct
void cvt_date(char const *date, char const *time) {
  Serial.println("setting localTime to compile time " __DATE__ " " __TIME__);
  char s_month[5];
  int year;
  static const char month_names[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
  sscanf(date, "%s %d %d", s_month, &localTime.tm_mday, &year);
  sscanf(time, "%2d %*c %2d %*c %2d", &localTime.tm_hour, &localTime.tm_min, &localTime.tm_sec);
  // Find where is s_month in month_names. Deduce month value.
  localTime.tm_mon = (strstr(month_names, s_month) - month_names) / 3;    
  localTime.tm_year = year - 1900;
  localTime.tm_isdst = -1;
//Serial.println(&localTime, "compile time localTime: %A, %B %d %Y %H:%M:%S");

  struct timeval tv = { 0 };
  tv.tv_sec = mktime(&localTime);  // seconds since epoch
  settimeofday(&tv, NULL);
  return;
}

void setTime() {
  configTzTime("EST5EDT,M3.2.0,M11.1.0", "time.google.com", "us.pool.ntp.org");

  // if you have a WiFi connection, retrive the date and time from SNTP
  sntp_set_time_sync_notification_cb(timeSyncCallback);  // set SNTP callback

  getLocalTime(&localTime, 1);
  if(!isLocalTimeValid()) {  // if localTime hasn't been set, init date/time from compile date/time
    cvt_date(__DATE__, __TIME__);
  }
  Serial.println(&localTime, "setTime localTime: %A, %B %d %Y %H:%M:%S");
}
