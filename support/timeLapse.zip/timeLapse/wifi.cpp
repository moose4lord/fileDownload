#include "timeLapse.h"

const char* ssid = "moose.net";
const char* password = "mooselord";

AsyncWebServer server(80);

void configServer();

bool initWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setHostname("timeLapse");
  WiFi.begin(ssid, password);
  Serial.print("Connecting to "); Serial.print(ssid);

  int wifiConnectCount = 20;  // wait for WiFi connection
  while (WiFi.status() != WL_CONNECTED && (--wifiConnectCount > 0)) {
    Serial.print('.');
    delay(1000);
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Connection failed");
    WiFi.disconnect(true, true);
    return false;
  }

  Serial.print("Server MAC addr: "); Serial.println(WiFi.macAddress());
  Serial.print("Server IP: "); Serial.println(WiFi.localIP());
  Serial.print("Server hostname: "); Serial.println(WiFi.getHostname());
  Serial.print("RSSI: "); Serial.printf("%ddB\n", WiFi.RSSI());

  configServer();  // configure the HTTP server

  return true;
}

bool interceptor(AsyncWebServerRequest *request) {
  resetSleepTimer();
  Serial.print("HTTP request: "); Serial.printf("HTTP %s %s%s\n", request->methodToString(),
    request->host(), request->url());
  return true;
}

void configServer() {
  server.onNotFound([](AsyncWebServerRequest *request) {
    resetSleepTimer();
    request->send(404, "text/plain", "Page not found");
  });

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    resetSleepTimer();
    request->send(SD, "/index.html", "text/html");
  });

  server.on("/picture", HTTP_GET, [](AsyncWebServerRequest * request) {
    Serial.println("HTTP picture");
    resetSleepTimer();

    camera_fb_t * frame = esp_camera_fb_get();
    request->send_P(200, "image/jpeg", (const uint8_t *)frame->buf, frame->len);
    delay(10);
    esp_camera_fb_return(frame);
  });

  // server.on("/status", HTTP_GET, [](AsyncWebServerRequest *request) {
  //   char buffer[180];
  //   snprintf(buffer, sizeof(buffer), "{\"status\":200, \"message\":\"OK\", \"sketch\":\"%s\", \"version\":\"%s\", \"SSID\":\"%s\", \"IP\":\"%s\", \"hostname\":\"%s\"}", SKETCH_NAME, VERSION, WiFi.SSID(), WiFi.localIP().toString(), WiFi.getHostname());
  //   Serial.println(buffer);

  //   AsyncWebServerResponse *response = request->beginResponse(200, "application/json", buffer);
  //   response->addHeader("Access-Control-Allow-Origin", "*");  // CORS header
  //   request->send(response);
  // });

  server.on("/list", HTTP_GET, [](AsyncWebServerRequest *request) {
    Serial.println("HTTP list");
    resetSleepTimer();

    char buffer[2000] = "[ ";  // start a JSON array
    listDirJSON("/", buffer, sizeof(buffer));
  
    AsyncWebServerResponse *response = request->beginResponse(200, "application/json", buffer);
    response->addHeader("Access-Control-Allow-Origin", "*");  // CORS header
    request->send(response);
  });

  // server.on("/image", HTTP_GET, [](AsyncWebServerRequest *request) {
  //   Serial.println("HTTP image");
  //   if (request->hasParam("name")) {
  //     char path[32];
  //     AsyncWebParameter* p = request->getParam("name");
  //     sprintf(path, "/%s", p->value().c_str());  // prepend a slash
  //     Serial.print("image path:"); Serial.println(path);

  //     AsyncWebServerResponse *response = request->beginResponse(SD, path, "image/jpeg");
  //     response->addHeader("Access-Control-Allow-Origin", "*");  // CORS header
  //     request->send(response);
  //   }
  //   delay(500);
  // });

  server.on("/erase", HTTP_GET, [](AsyncWebServerRequest *request) {
    Serial.println("HTTP erase");
    resetSleepTimer();

    eraseSD(".jpg");
    request->send(200, "text/plain", "Erase success!");
  });

//server.serveStatic("/", SD, "/");
  server.serveStatic("/", SD, "/").setFilter(interceptor);

  server.begin();
}

// void sendFile(char *path) {
//   if (sdFat.exists(path)) {
//     char buf[512];
//     FsFile file = sdFat.open(path, O_RDONLY);
//     size_t size = file.size();
//     server.setContentLength(size);
//     server.send(200, contentType, "");
//     while(size) {
//       size_t nread = file.readBytes(buf, sizeof(buf));
//       server.client().write(buf, nread);
//       size -= nread;
//     }
//     file.close();
//   }
// }
